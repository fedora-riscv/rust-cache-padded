# Version 1.3.0

- This crate is now deprecated in favor of [crossbeam-utils::CachePadded](https://docs.rs/crossbeam-utils/latest/crossbeam_utils/struct.CachePadded.html).

# Version 1.2.0

- Improve implementation of `CachePadded`. (#8)

# Version 1.1.1

- Forbid unsafe code.

# Version 1.1.0

- Mark `CachePadded::new()` as const fn.

# Version 1.0.0

- Initial version
